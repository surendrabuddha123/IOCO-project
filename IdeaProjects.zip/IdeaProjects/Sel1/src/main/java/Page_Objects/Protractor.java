package Page_Objects;

public class Protractor {
    public final String Add_User="XPATH||//button[contains(@class, 'btn btn-link pull-right')]";
}
