package Page_Objects;

public class Add_User {
    public final String First_Name="NAME||FirstName";
    public final String Last_Name="NAME||LastName";
    public final String UserName="NAME||UserName";
    public final String Password="NAME||Password";
    public final String Company_AAA="XPATH||//input[@type='radio'][@value='15']";
    public final String Company_BBB="XPATH||//input[@type='radio'][@value='16']";
    public final String Role="XPATH||//select[@name='RoleId']";
    public final String Email="NAME||Email";
    public final String Mobilephone="NAME||Mobilephone";
    public final String Save="XPATH||//button[@class='btn btn-success'][contains(text(), 'Save')]";
}
