package Utils;
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//


import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.log4j.Logger;

public class ExtentReportManager {
    private static Logger LOG = Logger.getLogger(ExtentReportManager.class);
    public static ExtentReports extentReport;
    private static ExtentReportManager report;
    public static List<ExtentTest> tests;
    String htmlReportFileName = "TestReport";
    private static String groupName = "";
    private static Map<String, ExtentReportManager> instances = new ConcurrentHashMap();
    private static Map<String, List<ExtentTest>> reportTestsMap = new ConcurrentHashMap();

    private ExtentReportManager(String reportName, String reportTitle, String reportPath) {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath);
        htmlReporter.config().setReportName(reportName);
        htmlReporter.config().setDocumentTitle(reportTitle);
        htmlReporter.config().setEncoding("UTF-8");
        extentReport = new ExtentReports();
        extentReport.attachReporter(new ExtentReporter[]{htmlReporter});
        extentReport.setSystemInfo("os", System.getProperty("os.name"));
        extentReport.setSystemInfo("user name", System.getProperty("user.name"));
        extentReport.setSystemInfo("java home", System.getProperty("java.home"));
        extentReport.setSystemInfo("java version", System.getProperty("java.version"));
    }

    private ExtentReportManager(String clazz) {
        String dateString = (new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss")).format(new Date());
        String destinationFolder = System.getProperty("user.dir") + File.separator + "Reports" + File.separator + clazz + File.separator + dateString;
        File folder;
        if (!(folder = new File(destinationFolder)).exists()) {
            folder.mkdirs();
        }

        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(destinationFolder + File.separator + this.htmlReportFileName + ".html");
        htmlReporter.config().setReportName(this.getClass().getSimpleName());
        htmlReporter.config().setDocumentTitle(this.htmlReportFileName);
        htmlReporter.config().setEncoding("UTF-8");
        extentReport = new ExtentReports();
        extentReport.attachReporter(new ExtentReporter[]{htmlReporter});
        extentReport.setSystemInfo("os", System.getProperty("os.name"));
        extentReport.setSystemInfo("user name", System.getProperty("user.name"));
        extentReport.setSystemInfo("java home", System.getProperty("java.home"));
        extentReport.setSystemInfo("java version", System.getProperty("java.version"));
    }

    public static synchronized void getInstance(Class testClazz) {
        String className = testClazz.getName();
        groupName = System.getProperty("groups");
        LOG.info("Group selected for reporting :: " + groupName);
        LOG.debug("get report instance for " + className);

        try {
            Class.forName(className);
        } catch (ClassNotFoundException var9) {
            LOG.debug("ClassNotFoundException: " + className);
        }

        if (groupName != null) {
            LOG.debug("get report instance for " + groupName);
            String groupClassName = null;

            try {
                Class.forName(groupName);
                groupClassName = Class.forName(groupName).getSimpleName();
            } catch (ClassNotFoundException var8) {
                LOG.debug("ClassNotFoundException: " + groupName);
            }

            if (!instances.containsKey(groupName)) {
                LOG.debug("creating report instance for " + groupName);
                Class var3 = ExtentReportManager.class;
                synchronized(ExtentReportManager.class) {
                    if (!instances.containsKey(groupName)) {
                        instances.put(groupName, new ExtentReportManager(groupClassName));
                        LOG.debug("new report created");
                    }

                    LOG.debug("report instance created for  " + groupName);
                }
            }
        } else if (!instances.containsKey(className)) {
            LOG.debug("creating report instance for " + className);
            Class var10 = ExtentReportManager.class;
            synchronized(ExtentReportManager.class) {
                if (!instances.containsKey(className)) {
                    instances.put(className, new ExtentReportManager(testClazz.getSimpleName()));
                    LOG.debug("new report created");
                }

                LOG.debug("report instance created for  " + className);
            }
        }

        if (groupName != null) {
            LOG.debug("return report  instance " + instances.get(groupName));
            report = (ExtentReportManager)instances.get(groupName);
            reportTestsMap.put(groupName, new ArrayList());
            tests = (List)reportTestsMap.get(groupName);
        } else {
            LOG.debug("return report  instance " + instances.get(className));
            report = (ExtentReportManager)instances.get(className);
            reportTestsMap.put(className, new ArrayList());
            tests = (List)reportTestsMap.get(className);
        }

    }

    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }
}
