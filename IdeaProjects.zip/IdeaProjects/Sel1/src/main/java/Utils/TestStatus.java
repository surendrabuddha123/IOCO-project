package Utils;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

public enum TestStatus {
    PASS("SCENARIO PASSED"),
    FAIL("SCENARIO FAILED"),
    FATAL("SCENARIO FATAL ERROR"),
    INFO("SCENARIO INFO"),
    SKIP("SCENARIO SKIPPED"),
    ERROR("SCENARIO ERROR");

    String testStatus;
    String statusDescription;

    private TestStatus(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getTestStatus() {
        return this.testStatus;
    }

    public String getStatusDescription() {
        return this.statusDescription;
    }
}

