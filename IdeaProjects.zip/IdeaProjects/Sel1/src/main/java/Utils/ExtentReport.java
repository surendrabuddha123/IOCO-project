package Utils;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//


import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import org.apache.log4j.Logger;

public class ExtentReport {
    private static String absoluteLink = "<a href='file:///{filePath}'>{displayName}</a>";
    private static String relativeLink = "<a href='./{filePath}'>{displayName}</a>";
    private static Logger LOG = Logger.getLogger(ExtentReport.class);

    public ExtentReport() {
    }

    public static void addTest(String testCaseName, String testCaseDescription, String categoryName) {
        if (ExtentReportManager.extentReport == null) {
            throw new RuntimeException("Extent report not found. Please call ExtentReportManager to generate a report for your test class");
        } else {
            LOG.debug("Extent:" + ExtentReportManager.extentReport);
            ExtentReportManager.tests.add(ExtentReportManager.extentReport.createTest(testCaseName, testCaseDescription).assignCategory(new String[]{categoryName}));
        }
    }

    public static void addTest(String testCaseName, String categoryName) {
        if (ExtentReportManager.extentReport == null) {
            throw new RuntimeException("Extent report not found. Please call ExtentReportManager to generate a report for your test class");
        } else {
            ExtentReportManager.tests.add(ExtentReportManager.extentReport.createTest(testCaseName).assignCategory(new String[]{categoryName}));
        }
    }

    public static void addTest(String testCaseName) {
        if (ExtentReportManager.extentReport == null) {
            throw new RuntimeException("Extent report not found. Please call ExtentReportManager to generate a report for your test class");
        } else {
            ExtentReportManager.tests.add(ExtentReportManager.extentReport.createTest(testCaseName));
        }
    }

    private static void updateInfoToReport() {
        ExtentReportManager.extentReport.flush();
    }

    public static void addCodeBlock(String codeContent) throws Exception {
        getCurrentTest().log(Status.INFO, MarkupHelper.createCodeBlock(codeContent));
        ExtentReportManager.extentReport.flush();
    }

    public static void addAttachment(String reportBaseDirectory, String fullFileName) throws Exception {
        File parentFile;
        if (!(parentFile = new File(reportBaseDirectory)).exists()) {
            throw new IOException(String.format("Add Attachment.The specified report base directory %s does not exist", reportBaseDirectory));
        } else {
            File parent = parentFile.getCanonicalFile();
            if (!parent.isDirectory()) {
                throw new IOException(String.format("Add Attachment.The specified report base %s is not a directory", reportBaseDirectory));
            } else {
                File file;
                if (!(file = new File(fullFileName)).exists()) {
                    throw new IOException(String.format("Add Attachment.The specified file %s does not exist", fullFileName));
                } else {
                    File child = file.getCanonicalFile();
                    boolean isChild = false;

                    String relativePath;
                    for(relativePath = null; child != null; child = child.getParentFile()) {
                        if (child.equals(parent)) {
                            isChild = true;
                            break;
                        }
                    }

                    if (isChild) {
                        relativePath = Paths.get(reportBaseDirectory).relativize(Paths.get(fullFileName)).toString();
                        getCurrentTest().log(Status.INFO, relativeLink.replace("{filePath}", relativePath).replace("{displayName}", file.getName()));
                    } else {
                        getCurrentTest().log(Status.INFO, absoluteLink.replace("{filePath}", fullFileName).replace("{displayName}", fullFileName));
                    }

                    ExtentReportManager.extentReport.flush();
                }
            }
        }
    }

    public static void reportEventWithScreenshot(TestStatus testStatus, String screenshotPath) {
        reportEventWithScreenshot(testStatus, "", screenshotPath);
    }

    public static void reportEventWithScreenshot(TestStatus testStatus, String description, String screenshotPath) {
        try {
            if (ExtentReportManager.extentReport == null) {
                throw new RuntimeException("Extent report not found. Please call ExtentReportManager to generate a report for your test class");
            }

            if (ExtentReportManager.tests == null) {
                throw new RuntimeException("Extent report. There are no test to report in. Please call addTest()");
            }

            switch(testStatus) {
                case PASS:
                    getCurrentTest().log(Status.PASS, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                    break;
                case FAIL:
                    getCurrentTest().log(Status.FAIL, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                    break;
                case FATAL:
                    getCurrentTest().log(Status.FATAL, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                    break;
                case INFO:
                    getCurrentTest().log(Status.INFO, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                    break;
                case SKIP:
                    getCurrentTest().log(Status.SKIP, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                    break;
                case ERROR:
                    getCurrentTest().log(Status.ERROR, description, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
            }

            updateInfoToReport();
        } catch (Exception var4) {
            var4.printStackTrace();
        }

    }

    public static void reportEvent(TestStatus testStatus, String description) {
        try {
            if (ExtentReportManager.extentReport == null) {
                throw new RuntimeException("Extent report not found. Please call ExtentReportManager to generate a report for your test class");
            }

            if (ExtentReportManager.tests == null) {
                throw new RuntimeException("Extent report. There are no test to report in. Please call addTest()");
            }

            switch(testStatus) {
                case PASS:
                    getCurrentTest().log(Status.PASS, description);
                    break;
                case FAIL:
                    getCurrentTest().log(Status.FAIL, description);
                    break;
                case FATAL:
                    getCurrentTest().log(Status.FATAL, description);
                    break;
                case INFO:
                    getCurrentTest().log(Status.INFO, description);
                    break;
                case SKIP:
                    getCurrentTest().log(Status.SKIP, description);
                    break;
                case ERROR:
                    getCurrentTest().log(Status.ERROR, description);
            }

            updateInfoToReport();
        } catch (Exception var3) {
            var3.printStackTrace();
        }

    }

    public static Status getRunStatus() throws Exception {
        return getCurrentTest().getStatus();
    }

    public static void setReportingStyle(TestStatus testStatus, String description, String screenshotPath, Boolean reportWithScreen) {
        try {
            String reportWithScreens = System.getProperty("reportWithScreens");
            if (reportWithScreens != null) {
                if (reportWithScreens.equalsIgnoreCase("true")) {
                    reportEventWithScreenshot(testStatus, description, screenshotPath);
                } else if (reportWithScreens.equalsIgnoreCase("false")) {
                    reportEvent(testStatus, description);
                }
            } else if (reportWithScreen) {
                reportEventWithScreenshot(testStatus, description, screenshotPath);
            } else {
                reportEvent(testStatus, description);
            }
        } catch (Exception var5) {
            var5.printStackTrace();
        }

    }

    public static ExtentTest getCurrentTest() throws Exception {
        if (ExtentReportManager.tests.size() > 0) {
            return (ExtentTest)ExtentReportManager.tests.get(ExtentReportManager.tests.size() - 1);
        } else {
            throw new Exception("Extent report. getCurrentTest. There are no test to report in. Please call addTest() first");
        }
    }

    public static void testPassed() {
        reportEvent(TestStatus.PASS, "SCENARIO PASSED");
    }

    public static void testPassed(String description) {
        reportEvent(TestStatus.PASS, description);
    }

    public static void testFailed() {
        reportEvent(TestStatus.FAIL, "SCENARIO FAILED");
    }

    public static void testFailed(String description) {
        reportEvent(TestStatus.FAIL, description);
    }

    public static void testInfo() {
        reportEvent(TestStatus.INFO, TestStatus.INFO.name());
    }

    public static void testInfo(String description) {
        reportEvent(TestStatus.INFO, description);
    }

    public static void testSkipped() {
        reportEvent(TestStatus.SKIP, "SCENARIO SKIPPED");
    }

    public static void testSkipped(String description) {
        reportEvent(TestStatus.SKIP, description);
    }

    public static void testError() {
        reportEvent(TestStatus.ERROR, "SCENARIO ERROR");
    }

    public static void testError(String description) {
        reportEvent(TestStatus.ERROR, description);
    }

    public static void testFatal() {
        reportEvent(TestStatus.FATAL, "SCENARIO FATAL");
    }

    public static void testFatal(String description) {
        reportEvent(TestStatus.FATAL, description);
    }
}
