package Test_Cases;

import Utils.CommonUtil;
import Utils.ExcelUtils;
import Utils.ExtentReport;
import Utils.TestStatus;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.IOException;

public class CIB_Assessment_1 {
    ExcelUtils ExcelUtils=new ExcelUtils();
    String [][] Excel_CIB_value;

    @Test
    public void Dog_API() throws IOException
    {
        //Retrieving list of all dog breeds
        Excel_CIB_value=ExcelUtils.readExcelDataFileToArray("src/test/resources/CIB_Assessment.xlsx","API_Details");
        CommonUtil.initiateExtentReport("Assessment",CIB_Assessment_1.class);
        ExtentReport.addTest("CIB_Assessment1");
        RestAssured.baseURI = Excel_CIB_value[1][0];
        RequestSpecification httpRequest = RestAssured.given();
        Response response = httpRequest.request(Method.GET, "/all");
        String responseBody = response.getBody().asString();
        ExtentReport.reportEvent(TestStatus.PASS,"List of All Dog Breeds: "+"<br/>"+"<br/>"+responseBody);

        //Verifying whether Retreiver Breed is within the list
        Assert.assertTrue(responseBody.contains("retriever"));
        ExtentReport.reportEvent(TestStatus.PASS,"Retriever Breed is within the list");

        //Retrieving list of retriever Breed
        RestAssured.baseURI = Excel_CIB_value[1][1];
        RequestSpecification httpRequest2 = RestAssured.given();
        Response response2 = httpRequest2.request(Method.GET, "/list");
        String responseBody2 = response2.getBody().asString();
        ExtentReport.reportEvent(TestStatus.PASS,"List of Retriever Breed List: "+"<br/>"+"<br/>"+responseBody2);

        //Retrieving image for sub breed "Golden"
        RestAssured.baseURI = Excel_CIB_value[1][2];
        RequestSpecification httpRequest3 = RestAssured.given();
        Response response3 = httpRequest3.request(Method.GET, "/random");
        String responseBody3 = response3.getBody().asString();
        ExtentReport.reportEvent(TestStatus.PASS,"Image of Golden Sub Breed "+"<br/>"+"<br/>"+responseBody3);
    }
}
