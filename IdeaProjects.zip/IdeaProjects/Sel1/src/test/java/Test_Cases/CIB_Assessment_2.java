package Test_Cases;

import Page_Objects.Protractor;
import Page_Objects.Add_User;
import Utils.CommonUtil;
import Utils.ExcelUtils;
import Utils.ExtentReport;
import Utils.TestStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CIB_Assessment_2
{
    WebDriver driver;
    String name;
    int p;
    String [][] Excel_CIB_value;
    String [][] Webtable_User;
    String [][] Excel_CIB_UserDetails;
    Protractor Protractor=new Protractor();
    Add_User Add_User=new Add_User();
    ExcelUtils ExcelUtils=new ExcelUtils();

    @BeforeTest
    public void Launch() throws IOException
    {
        System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
        // Instantiate a ChromeDriver class.
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Reading Values from Excel
        Excel_CIB_value=ExcelUtils.readExcelDataFileToArray("src/test/resources/CIB_Assessment.xlsx","Login");
        driver.get(Excel_CIB_value[1][0]);
    }

    @Test
    public void CIB_Assessment2() throws IOException
    {
        CommonUtil CommonUtil=new CommonUtil(driver);
        CommonUtil.initiateExtentReport("Assessment",CIB_Assessment_2.class);
        Excel_CIB_UserDetails=ExcelUtils.readExcelDataFileToArray("src/test/resources/CIB_Assessment.xlsx","UserDetails");
        ExtentReport.addTest("CIB_Assessment2");

        //Fetching Webtable Row Count
        List<WebElement> rows = driver.findElements(By.xpath("//table[@class='smart-table table table-striped']/tbody/tr/td[1]"));
         for (WebElement element : rows)
        {
            String name = element.getText();
            if (name.equals("Surendra"))
            {
                p=1;
            }
        }
        if (p==1)
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.FAIL,"My Name is  present in User List Table",CommonUtil.captureScreenshot("Username Validation"));
        }
        else
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.PASS,"My Name is not present in User List Table",CommonUtil.captureScreenshot("Username Validation"));
        }

        //Adding 2 Users to User list Table
        for (int i=1;i<=2;i++)
        {
            CommonUtil.clickOnElement(Protractor.Add_User);
            CommonUtil.typeOnElement(Add_User.First_Name, Excel_CIB_UserDetails[i][0]);
            CommonUtil.typeOnElement(Add_User.Last_Name, Excel_CIB_UserDetails[i][1]);
            CommonUtil.typeOnElement(Add_User.UserName, Excel_CIB_UserDetails[i][2]);
            CommonUtil.typeOnElement(Add_User.Password, Excel_CIB_UserDetails[i][3]);
            if(i==1)
            {
                CommonUtil.clickOnElement(Add_User.Company_AAA);
            }
            else
            {
                CommonUtil.clickOnElement(Add_User.Company_BBB);
            }
            CommonUtil.selectFromList(Add_User.Role, Excel_CIB_UserDetails[i][4]);
            CommonUtil.typeOnElement(Add_User.Email, Excel_CIB_UserDetails[i][5]);
            CommonUtil.typeOnElement(Add_User.Mobilephone, Excel_CIB_UserDetails[i][6]);
            ExtentReport.reportEventWithScreenshot(TestStatus.PASS,"User "+(i)+" Details",CommonUtil.captureScreenshot("Add_User"));
            CommonUtil.clickOnElement(Add_User.Save);
        }

       //Validating User 1 Details with the values present in Excel sheet
        List<WebElement> User1 = driver.findElements(By.xpath("//table[@class='smart-table table table-striped']/tbody/tr[1]/td"));
         if(User1.get(0).getText().equals(Excel_CIB_UserDetails[2][0])  && User1.get(1).getText().equals(Excel_CIB_UserDetails[2][1]) && User1.get(2).getText().equals(Excel_CIB_UserDetails[2][2]) && User1.get(5).getText().equals(Excel_CIB_UserDetails[2][4]) && User1.get(6).getText().equals(Excel_CIB_UserDetails[2][5]) && User1.get(7).getText().equals(Excel_CIB_UserDetails[2][6]))
            {
                ExtentReport.reportEventWithScreenshot(TestStatus.PASS,"User 1 Details are inserted correctly in the Webtable",CommonUtil.captureScreenshot("User1"));
            }
         else
            {
                ExtentReport.reportEventWithScreenshot(TestStatus.FAIL,"User 1 Details are incorrect",CommonUtil.captureScreenshot("User1"));
            }

      //Validating User 2 Details with the values present in Excel sheet
        List<WebElement> User2 = driver.findElements(By.xpath("//table[@class='smart-table table table-striped']/tbody/tr[2]/td"));
        if(User2.get(0).getText().equals(Excel_CIB_UserDetails[1][0])  && User2.get(1).getText().equals(Excel_CIB_UserDetails[1][1]) && User2.get(2).getText().equals(Excel_CIB_UserDetails[1][2]) && User2.get(5).getText().equals(Excel_CIB_UserDetails[1][4]) && User2.get(6).getText().equals(Excel_CIB_UserDetails[1][5]) && User2.get(7).getText().equals(Excel_CIB_UserDetails[1][6]))
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.PASS,"User 2 Details are inserted correctly in the Webtable",CommonUtil.captureScreenshot("User1"));
        }
        else
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.FAIL,"User 2 Details are incorrect",CommonUtil.captureScreenshot("User1"));
        }

        //Validating whether UserName is unique on each run
        List<WebElement> UserName_List = driver.findElements(By.xpath("//table[@class='smart-table table table-striped']/tbody/tr/td[3]"));
        ArrayList<String> UserName_String = new ArrayList<String>();
        for (WebElement column : UserName_List)
        {
            //converting webelements to String
            UserName_String.add(column.getText().toString());
        }
        if(UserName_String.size()==UserName_String.stream().distinct().count())
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.PASS,"Values in User name column is unique",CommonUtil.captureScreenshot("Unique"));
        }
       else
        {
            ExtentReport.reportEventWithScreenshot(TestStatus.FAIL,"Values in User name column is not unique",CommonUtil.captureScreenshot("Not Unique"));
        }
    }
}